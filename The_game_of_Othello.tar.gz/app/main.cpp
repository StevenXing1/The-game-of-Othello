// main.cpp
//
// ICS 46 Winter 2022
// Project #3: Black and White
//
// This is the program's main() function, which launches the GUI.  You will
// not want to make any changes to this file.

#include "OthelloApplication.hpp"


int main(int argc, char** argv)
{
    OthelloApplication{}.run(argc, argv);
    return 0;
}

/*
#include <memory>
#include <ics46/factory/DynamicFactory.hpp>
#include "OthelloAI.hpp"
#include "OthelloGameState.hpp"
#include "OthelloGameStateFactory.hpp"
#include "MyOthello.hpp"
#include <iostream>
// You'll also need to #include your own AI's header file here


int main()
{
    // This is how to create objects of the provided AI classes.  All are
    // registered with the ICS 46 DynamicFactory, so this is how you ask
    // for one of them to be built.
    std::unique_ptr<OthelloAI> randomAI =
        ics46::factory::DynamicFactory<OthelloAI>::instance()
        .make("Random Move (Provided)");

    // You can create an object of your own AI without all the ceremony,
    // since you have a full class declaration for it, though you will
    // need to remember to specify the namespace.
    haiyix2::MyOthello myAI;
    haiyix2::MyOthello myDadAI;
    myDadAI.switch1 = true;
    // This creates an 8x8 game state with the usual pattern of tiles in
    // the center area.
    for(int i = 0; i< 10; i++){
        std::unique_ptr<OthelloGameState> state =
            OthelloGameStateFactory{}.makeNewGameState(8, 8);
    
        while (!state->isGameOver())
        {
            // The "auto [x, y]" technique here is something called a "structured
            // binding".  Since chooseMove() returns a std::pair (i.e., something
            // that has two values in it), we can use this technique to assign
            // those two values into separate variables, where those variables'
            // types will automatically be determined to be int, since both of
            // the types in the std::pair are int.
            auto [x, y] = state->isBlackTurn()
                ? myDadAI.chooseMove(*state)
                : myAI.chooseMove(*state);

            state->makeMove(x, y);
        }
        std::cout<<state->whiteScore()<<"   "<<state->blackScore()<<std::endl;
    }

    

    return 0;
}
*/