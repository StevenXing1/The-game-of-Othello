#include <ics46/factory/DynamicFactory.hpp>
#include "MyOthello.hpp"


ICS46_DYNAMIC_FACTORY_REGISTER(OthelloAI, haiyix2::MyOthello, "My super man(Required)");

const int MAX_DEPTH = 5; //This defines the depth of the algorithm
int haiyix2::MyOthello::evaluation(const OthelloGameState& state, bool isBlack){
    if(isBlack){  
        return state.blackScore(); //It returns the score of my AI
    }
    else{
        return state.whiteScore(); //It returns the score of my AI  
    }
}

std::pair<int, int> haiyix2::MyOthello::chooseMove(const OthelloGameState& state)
{
    // implementation of the AI goes here

    if(state.isBlackTurn()){
        search(state, true, MAX_DEPTH);
    }
    else{
        search(state, false, MAX_DEPTH);
    }



    return result;
}


int haiyix2::MyOthello::search(const OthelloGameState& state, bool isBlack, int depth){
    int max = -1;   //The smallest value for max is 0 so I set max start with -1
    int min = state.board().width()*state.board().height()+1; //The biggest possible value for min is width*height so I set it to be width*height+1

    if(state.isGameOver() || depth == 0){       //If game is over or depth is 0, then we just return the score.
        
        return evaluation(state, isBlack);
    }
    if(state.isBlackTurn() == isBlack){         //Check if it's my AI's turn
        for(int x=0; x<state.board().width();x++){
            for(int y =0; y<state.board().height();y++){
                if(state.isValidMove(x,y)){
                    std::unique_ptr<OthelloGameState> p = state.clone();
                    p->makeMove(x,y);
                    
                    int current = search(*p, isBlack, depth-1);     //Get the score of the current step


                    if(current > max){
                        max = current;
                        if(depth == MAX_DEPTH){
                            result.first = x;
                            result.second = y;
                        }

                    }
                }
            }
        }
        return max;
    }

    else{
        //This part is for the opponent's turn and literally have the same logic as I do above except for the assigning value for result.first and result.second
        for(int x=0; x<state.board().width();x++){
            for(int y =0; y<state.board().height();y++){
                if(state.isValidMove(x,y)){
                    std::unique_ptr<OthelloGameState> p = state.clone();
                    p->makeMove(x,y);
                    int current = search(*p, isBlack, depth-1);     
                    if(current<min){
                        min = current;
                    }
                }
            }
        }
        return min;
    }
    

}



haiyix2::MyOthello::MyOthello()
        : result{std::make_pair(-1,-1)}
{
}
