#ifndef MYOTHELLO_HPP
#define MYOTHELLO_HPP

#include "OthelloAI.hpp"
#include <random>


namespace haiyix2
{
    class MyOthello : public OthelloAI
    {
    public:
        MyOthello();
        std::pair<int, int> chooseMove(const OthelloGameState& state) override;
        
        int evaluation(const OthelloGameState& state, bool isBlack);
        int search(const OthelloGameState& state, bool isBlack, int depth);


   
    private:
        std::pair<int, int> result;

        
    };
}

#endif